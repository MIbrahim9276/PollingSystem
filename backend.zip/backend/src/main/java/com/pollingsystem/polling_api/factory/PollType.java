package com.pollingsystem.polling_api.factory;

public enum PollType {
    SINGLE_CHOICE,
    MULTIPLE_CHOICE,
    RANKED_CHOICE
}
